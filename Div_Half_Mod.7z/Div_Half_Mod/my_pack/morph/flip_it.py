##
## flip_it module
##

def flip(var):
    var.reverse()
    return(var)