##
## doub_it Python module
##

def double(var):
    for i,v in enumerate(var):
        var[i] = v * 2
    return(var)