### Program

''' Bertha Wright: Lab Modules and Testing
Date: 02-Oct-2022
Assignment: Week 06
Pseudocode: None Needed
'''

### Main Program


def division():
    halfnum = float(input("Please type the number you want halved here: "))
    return halfnum // 2



