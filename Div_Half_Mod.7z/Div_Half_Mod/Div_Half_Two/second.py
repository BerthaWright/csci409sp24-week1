### Program

''' Bertha Wright: Lab Modules and Testing
Date: 02-Oct-2022
Assignment: Week 06
Pseudocode: None Needed
'''

### Main Program


def double():
    dub_num = float(input("Please type the number you want doubled here: "))
    return dub_num * 2

