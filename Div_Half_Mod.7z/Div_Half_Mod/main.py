### Program

''' Bertha Wright: Lab Modules and Testing
Date: 02-Oct-2022
Assignment: Week 06
Pseudocode: None Needed
'''

### Main Program

import first
import second

print(first.division())
print(second.double())
